package com.indymobile.app.model;

import p000.hv3;

/* JADX INFO: compiled from: r8-map-id-fd227b9ca2408bf12dab7890d81a029f48c8368719a26ab66e8084b55e10ecd8 */
/* JADX INFO: loaded from: classes2.dex */
public class PSImageEstimationInfoBean {
    public float blackPoint;
    public hv3 imageType;
    public float whitePoint;
}
