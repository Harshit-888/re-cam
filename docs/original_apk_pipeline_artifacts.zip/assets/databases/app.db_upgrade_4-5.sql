insert into paper_size values(63, 'Folio', 612, 936, 1, 1, 6, 'in');
