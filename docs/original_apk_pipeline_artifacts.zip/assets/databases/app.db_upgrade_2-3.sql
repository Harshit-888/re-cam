insert into paper_size values(62, 'Business Card', 353, 206, 1, 1, 6, 'in');

ALTER TABLE PAGE ADD COLUMN i_date_ocr NUMERIC;
ALTER TABLE PAGE ADD COLUMN i_date_note NUMERIC;
ALTER TABLE PAGE ADD COLUMN c_title TEXT;
ALTER TABLE PAGE ADD COLUMN i_jpg_quality NUMERIC DEFAULT 80;
