CREATE TABLE sync_stats_document ( `i_document_id` INTEGER PRIMARY KEY, `etag_model_local` TEXT, `etag_model_remote` TEXT);

CREATE TABLE sync_stats_page ( `i_page_id` INTEGER PRIMARY KEY, `etag_model_local` TEXT, `etag_model_remote` TEXT, `etag_image_local` TEXT, `etag_image_remote` TEXT);

CREATE TABLE `sync_history` ( `i_sync_history_id` INTEGER, `i_sync_cloud_type` INTEGER, `c_account_id` TEXT, `i_date_created` NUMERIC, `i_date_start` NUMERIC, `i_date_end` NUMERIC, `i_connection_status` INTEGER, `i_sync_status` INTEGER, `c_error_message` TEXT, `i_total_dir` INTEGER,`i_total_doc` INTEGER, `i_total_page` INTEGER, `i_local_dir_add` INTEGER, `i_local_dir_update` INTEGER, `i_local_dir_trash` INTEGER, `i_local_doc_add` INTEGER, `i_local_doc_update` INTEGER, `i_local_doc_trash` INTEGER, `i_local_page_add` INTEGER, `i_local_page_update` INTEGER, `i_local_page_trash` INTEGER, `i_remote_dir_add` INTEGER, `i_remote_dir_update` INTEGER, `i_remote_dir_trash` INTEGER, `i_remote_doc_add` INTEGER, `i_remote_doc_update` INTEGER, `i_remote_doc_trash` INTEGER, `i_remote_page_add` INTEGER, `i_remote_page_update` INTEGER, `i_remote_page_trash` INTEGER, PRIMARY KEY(`i_sync_history_id`) );

ALTER TABLE DOCUMENT ADD COLUMN i_date_trash NUMERIC;
ALTER TABLE DOCUMENT ADD COLUMN i_opt NUMERIC DEFAULT 0;
ALTER TABLE DOCUMENT ADD COLUMN c_opt TEXT;
ALTER TABLE DOCUMENT ADD COLUMN i_status NUMERIC DEFAULT 0;

ALTER TABLE PAGE ADD COLUMN i_file_type INTEGER DEFAULT 0;
ALTER TABLE PAGE ADD COLUMN i_date_trash NUMERIC;
ALTER TABLE PAGE ADD COLUMN i_opt NUMERIC DEFAULT 0;
ALTER TABLE PAGE ADD COLUMN c_opt TEXT;
ALTER TABLE PAGE ADD COLUMN i_status NUMERIC DEFAULT 0;